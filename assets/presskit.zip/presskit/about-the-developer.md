# About the developer

Hey there! 👋

I'm Dan. I'm a human from Ottawa, Canada who loves to learn and to teach. At the moment, I make a living build iOS apps.

I've been working full-time as an iOS developer since 2012. In the summer of 2019, I left a full-time gig to pursue freelancing and independent work, and since the start of 2020, I've been focused on getting more involved in the amazing iOS development community. Oh Bother is the first app I've released independently since 2013, and I couldn't be more excited to share it with the community, and with any luck, the world at large. 

You can find out more about me on [my website](https://danielgauthier.me), where I maintain an active blog about independent iOS development.

If you have any questions at all, feel free to reach out at danielgauthier.dev@gmail.com